/* 
Pattern2.java
Designed by: Jack Larkin
10/5
*/
public class Pattern2 {
  public static void main(String[] args) {
    int sum = 0;
    for (int i=0; i<=8; i++){
      // line number
      System.out.print(i+1);
      for (int j=0; j<=i; j++){
        System.out.print("*");
      }
      System.out.println("");
    }
  }
}
/*
java Pattern2
1*
2**
3***
4****
5*****
6******
7*******
8********
9*********
*/