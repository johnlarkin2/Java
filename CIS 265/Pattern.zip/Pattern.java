/*
Pattern.java
Designed by: Jack Larkin
*/
public class Pattern{
  // main method
  public static void main(String[] args) {

    // for loop
    int i, j, k = 1;
    int sum = 0;
    for (i=1; i<=5; i++){
    k=5-i;  
      // space
      for (j=1; j<=k; j++){
        System.out.print(" ");
      }
      // star
      for (j=1; j<=2*i-1; j++){
        System.out.print("*");
      }

      System.out.println("");
    }
    
    for (i=1; i<=4; i++){
      k=i;
      for (j=1; j<=k; j++){
         System.out.print(" ");
      }
      k++;
      for (j=1; j<=2*(5-i)-1; j++){
        System.out.print("*");
      }
      System.out.println("");
    }
  }
}
/*
 java Pattern
    *
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *
*/